$(document).ready(function () {
    $(document).mousemove(function (e) {
      var mouseX = e.pageX;
      var mouseY = e.pageY;
  
      var animal = $('#animal');
      var animalWidth = animal.width();
      var animalHeight = animal.height();
  
      var maxX = $(window).width() - animalWidth;
      var maxY = $(window).height() - animalHeight;
  
      var posX = mouseX - animalWidth / 2;
      var posY = mouseY - animalHeight / 2;
  
      posX = Math.min(Math.max(posX, 0), maxX);
      posY = Math.min(Math.max(posY, 0), maxY);
  
      animal.css({
        left: posX + 'px',
        top: posY + 'px',
      });
    });
  });
  