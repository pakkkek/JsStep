$(document).ready(function () {
    var menuContainer = $('#menu-container');
    var menuHeader = $('#menu-header');
  
    menuHeader.click(function () {
      menuContainer.css(
        'left',
        menuContainer.css('left') === '0px' ? '-200px' : '0'
      );
    });
  });
  