$(document).ready(() => {
    const products = [
      { id: 1, name: 'Product 1', price: 10.99 },
      { id: 2, name: 'Product 2', price: 19.99 },
      { id: 3, name: 'Product 3', price: 25.99 },
    ];
  
    // Load cart items from local storage
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  
    function displayProducts() {
      const $products = $('#products');
      $products.empty();
      products.forEach((product) => {
        const $product = $('<div>').addClass('product');
        $product.append($('<h3>').text(product.name));
        $product.append($('<p>').text(` Price: $${product.price.toFixed(2)}`));
        $product.append(
          $('<button>').text('Add to the cart').data('product', product)
        );
        $products.append($product);
      });
    }
  
    function displayCartItems() {
      const $cartItems = $('#cart-items');
      $cartItems.empty();
      cartItems.forEach((cartItem) => {
        $cartItems.append(
          $('<li>')
            .text(`${cartItem.name} - $${cartItem.price.toFixed(2)}`)
            .append($('<button>').text('Remove').data('cartItem', cartItem))
            .append(
              $('<input>')
                .attr({ type: 'number', min: 1, value: cartItem.quantity })
                .data('cartItem', cartItem)
                .on('input', updateCartItemQuantity)
            )
        );
      });
      updateTotal();
    }
  
    function updateTotal() {
      const total = cartItems.reduce(
        (acc, cartItem) => acc + cartItem.price * cartItem.quantity,
        0
      );
      $('#cart-total').text(`$${total.toFixed(2)}`);
    }
  
    function updateCartItemQuantity() {
      const $input = $(this);
      const quantity = parseInt($input.val());
      const cartItem = $input.data('cartItem');
      cartItem.quantity = quantity;
      updateTotal();
      saveCartItemsToLocalStorage();
    }
  
    function saveCartItemsToLocalStorage() {
      localStorage.setItem('cartItems', JSON.stringify(cartItems));
    }
  
    $(document).on('click', '.product button', function () {
      const product = $(this).data('product');
      const existingCartItem = cartItems.find((item) => item.id === product.id);
  
      if (existingCartItem) {
        existingCartItem.quantity += 1;
      } else {
        cartItems.push({ ...product, quantity: 1 });
      }
  
      saveCartItemsToLocalStorage();
      displayCartItems();
    });
  
    $(document).on('click', '#cart-items li button', function () {
      const cartItem = $(this).data('cartItem');
      const confirmDelete = confirm(
        'Are you sure you want to remove this product from the cart?'
      );
      if (confirmDelete) {
        const itemIndex = cartItems.indexOf(cartItem);
        cartItems.splice(itemIndex, 1);
        saveCartItemsToLocalStorage();
        displayCartItems();
      }
    });
  
    displayProducts();
    displayCartItems();
  });
  