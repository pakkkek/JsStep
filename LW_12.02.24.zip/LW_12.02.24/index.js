// 1
function generateRange(start, end) {
    const result = [];
    for (let i = start + 1; i < end; i++) {
      result.push(i);
    }
    return result;
  }
  
  // 2
  function isPalindrome(word) {
    const reversedWord = word.split('').reverse().join('');
    return word === reversedWord;
  }
  
  // 3
  function recursiveSort(arr) {
    if (arr.length <= 1) {
      return arr;
    }
  
    const pivot = arr[0];
    const less = arr.slice(1).filter((element) => element <= pivot);
    const greater = arr.slice(1).filter((element) => element > pivot);
  
    return [...recursiveSort(less), pivot, ...recursiveSort(greater)];
  }
  
  // 4
  function countVowels(str) {
    const vowels = ['a', 'e', 'i', 'o', 'u'];
    return str.split('').filter((char) => vowels.includes(char.toLowerCase()))
      .length;
  }
  
  // 5
  function sumNestedArrays(arr) {
    return arr
      .flat(Infinity)
      .filter(Number.isFinite)
      .reduce((acc, num) => acc + num, 0);
  }
  
  // 6
  function fibonacci(n) {
    if (n <= 1) {
      return n;
    }
    return fibonacci(n - 1) + fibonacci(n - 2);
  }
  
  // 7
  function reverseString(str) {
    if (str === '') {
      return '';
    }
    return reverseString(str.substr(1)) + str[0];
  }
  
  // 8
  function addIndexToObjects(arr) {
    return arr.map((obj, index) => ({ ...obj, index }));
  }
  
  // 9
  function isPrime(number) {
    if (number < 2) {
      return false;
    }
    for (let i = 2; i < number; i++) {
      if (number % i === 0) {
        return false;
      }
    }
    return true;
  }
  
  // 10
  function gcdOfArray(arr) {
    const findGCD = (x, y) => (y === 0 ? x : findGCD(y, x % y));
    return arr.reduce((acc, num) => findGCD(acc, num));
  }
  