const products = [
    { name: 'Product A', price: 20 },
    { name: 'Product B', price: 15 },
    { name: 'Product C', price: 30 },
    // ...
];

function renderProducts(productArray) {
    const productList = document.getElementById('productList');
    productList.innerHTML = '';

    productArray.forEach(product => {
        const listItem = document.createElement('li');
        listItem.textContent = `${product.name} - $${product.price}`;
        productList.appendChild(listItem);
    });
}

function mysort(arr, cmp) {
    return arr.slice().sort(cmp);
}

function getComparator() {
    const sortBy = document.getElementById('sortSelect').value;

    switch (sortBy) {
        case 'name':
            return (a, b) => a.name.localeCompare(b.name);
        case 'price':
            return (a, b) => a.price - b.price;
        // ...
        default:
            return () => 0;
    }
}

function sortProducts() {
    const comparator = getComparator();
    const sortedProducts = mysort(products, comparator);
    renderProducts(sortedProducts);
}

renderProducts(products);
